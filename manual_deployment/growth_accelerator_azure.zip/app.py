import os
from flask import Flask

app = Flask(__name__)
app.secret_key = "growth-accelerator-production"

@app.route('/')
def home():
    return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Growth Accelerator Platform</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            text-align: center;
            background: white;
            padding: 4rem 3rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 90%;
        }
        .logo { font-size: 3rem; margin-bottom: 1rem; color: #667eea; }
        h1 { color: #333; margin-bottom: 1rem; font-size: 2.5rem; }
        .tagline { color: #666; margin-bottom: 2rem; font-size: 1.2rem; }
        .btn {
            background: #667eea;
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-size: 1.1rem;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }
        .btn:hover { background: #5a6fd8; transform: translateY(-2px); }
        .status { margin-top: 2rem; color: #28a745; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">🚀</div>
        <h1>Growth Accelerator Staffing Platform</h1>
        <p class="tagline">Attract. Match. Hire. Onboard.</p>
        <a href="/workspace" class="btn">Enter Workspace</a>
        <div class="status">✓ Azure Deployment Active</div>
    </div>
</body>
</html>"""

@app.route('/workspace')
def workspace():
    return """<!DOCTYPE html>
<html>
<head>
    <title>Workspace - Growth Accelerator</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; margin: 0; }
        .header { background: #667eea; color: white; padding: 1rem 2rem; text-align: center; }
        .content { padding: 2rem; max-width: 800px; margin: 0 auto; }
        .card { background: white; padding: 2rem; border-radius: 10px; margin: 1rem 0; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .btn { background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; }
    </style>
</head>
<body>
    <div class="header"><h1>Growth Accelerator Workspace</h1></div>
    <div class="content">
        <div class="card">
            <h3>Platform Status</h3>
            <p>✓ Azure Web App deployment successful</p>
            <p>✓ Custom domain: app.growthaccelerator.nl</p>
            <p>✓ AI integration ready</p>
        </div>
        <div class="card">
            <h3>AI Suggestions</h3>
            <div id="suggestions">Loading AI suggestions...</div>
        </div>
        <a href="/" class="btn">Back to Landing</a>
    </div>
    <script>
        fetch('/api/ai/suggestions')
            .then(r => r.json())
            .then(data => {
                document.getElementById('suggestions').innerHTML = 
                    data.suggestions.map(s => '<p>• ' + s + '</p>').join('');
            })
            .catch(() => {
                document.getElementById('suggestions').innerHTML = '<p>AI services initializing...</p>';
            });
    </script>
</body>
</html>"""

@app.route('/api/ai/suggestions')
def ai_suggestions():
    return {
        "suggestions": [
            "Match candidates based on skills and experience",
            "Review job requirements for completeness",
            "Consider remote work opportunities"
        ],
        "status": "active"
    }

@app.route('/health')
def health():
    return {"status": "healthy", "service": "Growth Accelerator Platform"}, 200

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port)
